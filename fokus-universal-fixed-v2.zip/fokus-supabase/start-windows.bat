@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [ОШИБКА] Node.js не найден.
  echo Установи Node.js LTS: https://nodejs.org/
  echo После установки закрой это окно и запусти start-windows.bat снова.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo [ОШИБКА] npm не найден. Переустанови Node.js LTS с https://nodejs.org/
  pause
  exit /b 1
)

if not exist "node_modules\vite\bin\vite.js" (
  echo Устанавливаю зависимости. Нужен интернет, подожди...
  call npm install
  if errorlevel 1 (
    echo.
    echo [ОШИБКА] Не удалось установить зависимости.
    echo Проверь подключение к интернету и повтори запуск.
    pause
    exit /b 1
  )
)

echo.
echo Запускаю Фокус...
echo Открой в браузере: http://localhost:5173
start "" http://localhost:5173
echo Не закрывай это окно, пока пользуешься приложением.
echo Для остановки нажми Ctrl+C.
echo.
call npm run dev -- --host 0.0.0.0
if errorlevel 1 (
  echo.
  echo [ОШИБКА] Сервер не запустился. Попробуй удалить папку node_modules
  echo и запустить этот файл повторно.
  pause
)
