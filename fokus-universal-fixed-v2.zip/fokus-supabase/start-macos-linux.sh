#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "[ОШИБКА] Установи Node.js LTS: https://nodejs.org/"
  exit 1
fi

if [ ! -f "node_modules/vite/bin/vite.js" ]; then
  echo "Устанавливаю зависимости. Нужен интернет..."
  npm install
fi

echo "Фокус запускается: http://localhost:5173"
echo "Не закрывай это окно, пока пользуешься приложением."
exec npm run dev -- --host 0.0.0.0
